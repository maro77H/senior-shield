import 'dart:math' as math;
import 'dart:async';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_native_contact_picker/flutter_native_contact_picker.dart';

void main() {
  runApp(const SeniorShieldApp());
}


// Speech starts only when the user presses Listen.
final FlutterTts _voice = FlutterTts();
int _voiceRequest = 0;
double _voiceSpeed = 0.55;
Map<String, String>? _selectedVoice;

Future<void> speakVoice(String text) async {
  final request = ++_voiceRequest;
  await _voice.stop();
  if (request != _voiceRequest) return;
  await _voice.setLanguage(_selectedVoice?['locale'] ?? 'en-US');
  final choice = _selectedVoice;
  if (choice != null) {
    await _voice.setVoice({'name': choice['name']!, 'locale': choice['locale']!});
  }
  await _voice.setSpeechRate(_voiceSpeed);
  await _voice.setVolume(1.0);
  await _voice.setPitch(1.0);
  if (request != _voiceRequest) return;
  final result = await _voice.speak(text);
  if (result == 0) throw StateError('Voice could not start.');
}

Future<void> stopVoice() async {
  _voiceRequest++;
  try {
    await _voice.stop();
  } catch (_) {
    // Stopping is also called when a page closes or the app goes inactive.
  }
}

class VoiceControls extends StatefulWidget {
  const VoiceControls({
    super.key,
    required this.text,
    this.label = 'Listen to Instructions',
    this.showSettings = false,
  });

  final String Function() text;
  final String label;
  final bool showSettings;

  @override
  State<VoiceControls> createState() => _VoiceControlsState();
}

class _VoiceControlsState extends State<VoiceControls>
    with WidgetsBindingObserver {
  bool _starting = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  void _showError() {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Voice could not start. Check your media volume and English voice settings.',
        ),
      ),
    );
  }

  Future<void> _listen() async {
    final text = widget.text().trim();
    if (text.isEmpty || _starting) return;
    setState(() => _starting = true);
    try {
      await speakVoice(text);
    } catch (_) {
      _showError();
    } finally {
      if (mounted) setState(() => _starting = false);
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) unawaited(stopVoice());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    unawaited(stopVoice());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Wrap(
        alignment: WrapAlignment.center,
        spacing: 12,
        runSpacing: 8,
        children: [
          OutlinedButton.icon(
            onPressed: _starting ? null : _listen,
            icon: const Icon(Icons.volume_up, size: 28),
            label: Text(widget.label, style: const TextStyle(fontSize: 18)),
          ),
          if (widget.showSettings)
            TextButton.icon(
              onPressed: () async {
                await stopVoice();
                if (!context.mounted) return;
                await showDialog<void>(
                  context: context,
                  builder: (_) => const VoiceSettingsDialog(),
                );
              },
              icon: const Icon(Icons.tune, size: 28),
              label: const Text('Voice Settings', style: TextStyle(fontSize: 18)),
            ),
          TextButton.icon(
            onPressed: () => unawaited(stopVoice()),
            icon: const Icon(Icons.stop_circle_outlined, size: 28),
            label: const Text('Stop Voice', style: TextStyle(fontSize: 18)),
          ),
        ],
      ),
    );
  }
}


class VoiceSettingsDialog extends StatefulWidget {
  const VoiceSettingsDialog({super.key});

  @override
  State<VoiceSettingsDialog> createState() => _VoiceSettingsDialogState();
}

class _VoiceSettingsDialogState extends State<VoiceSettingsDialog>
    with WidgetsBindingObserver {
  List<Map<String, String>> _voices = [];
  bool _loading = true;
  bool _testing = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    unawaited(_loadVoices());
  }

  String _key(Map<String, String> voice) => '${voice['name']}|${voice['locale']}';

  Future<void> _loadVoices() async {
    setState(() { _loading = true; _error = null; });
    try {
      final raw = await _voice.getVoices;
      final unique = <String, Map<String, String>>{};
      if (raw is List) {
        for (final item in raw) {
          if (item is! Map) continue;
          final name = item['name']?.toString() ?? '';
          final locale = item['locale']?.toString() ?? '';
          if (name.isEmpty || !locale.toLowerCase().startsWith('en')) continue;
          final voice = <String, String>{
            'name': name,
            'locale': locale,
            'gender': item['gender']?.toString() ?? '',
          };
          unique[_key(voice)] = voice;
        }
      }
      if (!mounted) return;
      final voices = unique.values.toList()
        ..sort((a, b) => a['name']!.compareTo(b['name']!));
      if (voices.isNotEmpty &&
          (_selectedVoice == null || !unique.containsKey(_key(_selectedVoice!)))) {
        // Prefer an explicitly identified female voice when gender is supplied.
        _selectedVoice = voices.firstWhere(
          (v) => v['gender']!.toLowerCase() == 'female',
          orElse: () => voices.first,
        );
      }
      setState(() { _voices = voices; _loading = false; });
    } catch (_) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = 'Could not load voices. Please try again.';
        });
      }
    }
  }

  Future<void> _testVoice() async {
    setState(() { _testing = true; _error = null; });
    try {
      await speakVoice(
        'Hello, welcome to Senior Shield. I am here to help you stay safe. '
        'Take your time, and ask someone you trust if you are unsure.',
      );
    } catch (_) {
      if (mounted) setState(() => _error = 'This voice could not start. Try another voice.');
    } finally {
      if (mounted) setState(() => _testing = false);
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) unawaited(stopVoice());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    unawaited(stopVoice());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Voice Settings'),
      content: SizedBox(
        width: 420,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'Choose an English voice and press Test Voice to hear it. '
                'Female voices depend on what your device provides.',
                style: TextStyle(fontSize: 17),
              ),
              const SizedBox(height: 18),
              if (_loading)
                const Center(child: CircularProgressIndicator())
              else if (_voices.isEmpty)
                const Text('No English voices found yet. Try Reload Voices.')
              else
                DropdownButtonFormField<String>(
                  initialValue: _selectedVoice == null ? null : _key(_selectedVoice!),
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Voice', border: OutlineInputBorder(),
                  ),
                  items: _voices.map((voice) {
                    final gender = voice['gender']!;
                    return DropdownMenuItem<String>(
                      value: _key(voice),
                      child: Text(
                        '${voice['name']} (${voice['locale']})'
                        '${gender.isEmpty ? '' : ' - $gender'}',
                        overflow: TextOverflow.ellipsis,
                      ),
                    );
                  }).toList(),
                  onChanged: (key) {
                    if (key == null) return;
                    unawaited(stopVoice());
                    setState(() {
                      _selectedVoice = _voices.firstWhere((v) => _key(v) == key);
                    });
                  },
                ),
              TextButton(onPressed: _loading ? null : _loadVoices,
                  child: const Text('Reload Voices')),
              const SizedBox(height: 10),
              const Text('Speaking speed', style: TextStyle(fontSize: 18)),
              Slider(
                value: _voiceSpeed,
                min: 0.35,
                max: 0.75,
                divisions: 8,
                label: _voiceSpeed.toStringAsFixed(2),
                semanticFormatterCallback: (value) => 'Speed ${value.toStringAsFixed(2)}',
                onChanged: (value) {
                  unawaited(stopVoice());
                  setState(() => _voiceSpeed = value);
                },
              ),
              const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [Text('Slower'), Text('Faster')]),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: _loading || _testing ? null : _testVoice,
                icon: const Icon(Icons.volume_up),
                label: const Text('Test Voice'),
              ),
              TextButton.icon(
                onPressed: () => unawaited(stopVoice()),
                icon: const Icon(Icons.stop_circle_outlined),
                label: const Text('Stop Voice'),
              ),
              if (_error != null)
                Text(_error!, style: const TextStyle(color: Color(0xFFB3261E))),
              const SizedBox(height: 10),
              const Text('Your choice applies throughout the app until it restarts.'),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Done')),
      ],
    );
  }
}


class CyberBackground extends StatefulWidget {
  const CyberBackground({super.key, required this.child});
  final Widget child;

  @override
  State<CyberBackground> createState() => _CyberBackgroundState();
}

class _CyberBackgroundState extends State<CyberBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _motion = AnimationController(
    vsync: this, duration: const Duration(seconds: 36),
  );

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (MediaQuery.disableAnimationsOf(context)) {
      _motion.stop();
    } else if (!_motion.isAnimating) {
      _motion.repeat();
    }
  }

  @override
  void dispose() {
    _motion.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft, end: Alignment.bottomRight,
              colors: [Color(0xFF07111F), Color(0xFF0B1C32), Color(0xFF081322)],
            ),
          ),
        ),
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: Alignment(-0.8, -0.6), radius: 1.3,
              colors: [Color(0x3024B6D2), Color(0x0024B6D2)],
            ),
          ),
        ),
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: Alignment(0.9, 0.7), radius: 1.1,
              colors: [Color(0x253F59D8), Color(0x003F59D8)],
            ),
          ),
        ),
        IgnorePointer(
          child: RepaintBoundary(
            child: CustomPaint(painter: _CyberNetworkPainter(_motion)),
          ),
        ),
        widget.child,
      ],
    );
  }
}

class _CyberNetworkPainter extends CustomPainter {
  _CyberNetworkPainter(this.motion) : super(repaint: motion);
  final Animation<double> motion;

  @override
  void paint(Canvas canvas, Size size) {
    final phase = motion.value * math.pi * 2;
    final nodes = List<Offset>.generate(32, (i) {
      final x = ((i * 0.61803398875 + 0.07) % 1) * size.width;
      final y = ((i * 0.41421356237 + 0.11) % 1) * size.height;
      return Offset(
        x + math.sin(phase + i * 1.7) * 20,
        y + math.cos(phase + i * 1.3) * 24,
      );
    });
    final line = Paint()..color = const Color(0x245CCFE9)..strokeWidth = 1;
    final dot = Paint()..color = const Color(0x805CD8EC);
    final halo = Paint()..color = const Color(0x125CD8EC);
    final distance = math.min(210.0, size.shortestSide * 0.35);
    for (var i = 0; i < nodes.length; i++) {
      for (var j = i + 1; j < nodes.length; j++) {
        if ((nodes[i] - nodes[j]).distance < distance) {
          canvas.drawLine(nodes[i], nodes[j], line);
        }
      }
      canvas.drawCircle(nodes[i], 7, halo);
      canvas.drawCircle(nodes[i], 2, dot);
    }
  }

  @override
  bool shouldRepaint(covariant _CyberNetworkPainter oldDelegate) =>
      oldDelegate.motion != motion;
}

class SeniorShieldApp extends StatelessWidget {
  const SeniorShieldApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Senior Shield',
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF52DDEB),
          brightness: Brightness.dark,
        ).copyWith(
          primary: const Color(0xFF70EAF5),
          onPrimary: const Color(0xFF061522),
          surface: const Color(0xFF11233B),
          onSurface: const Color(0xFFF1F6FF),
        ),
        scaffoldBackgroundColor: Colors.transparent,
        canvasColor: const Color(0xFF11233B),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          surfaceTintColor: Colors.transparent,
          foregroundColor: Color(0xFFF1F6FF),
          elevation: 0,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xF011233B),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: const BorderSide(color: Color(0xFF54708A)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: const BorderSide(color: Color(0xFF70EAF5), width: 2),
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF70EAF5),
            foregroundColor: const Color(0xFF061522),
            elevation: 5,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: const Color(0xFFB3F7FF),
            backgroundColor: const Color(0xE611233B),
            side: const BorderSide(color: Color(0xFF547F98)),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          ),
        ),
      ),
      builder: (context, child) => CyberBackground(
        child: child ?? const SizedBox.shrink(),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: const Text(
          'Senior Shield',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 500),
            child: Column(
              children: [
                // Original Senior Shield artwork at the top of the home screen.
                ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: AspectRatio(
                    aspectRatio: 1024 / 500,
                    child: Image.asset(
                      'assets/branding/senior_shield_banner.jpg',
                      fit: BoxFit.contain,
                      semanticLabel:
                          'Senior Shield. Simple cybersecurity protection.',
                    ),
                  ),
                ),
                const SizedBox(height: 28),
                // Centered brand icon, with the animated background behind it.
                Container(
                  decoration: const BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x4061E9FF),
                        blurRadius: 55,
                        spreadRadius: 4,
                      ),
                    ],
                  ),
                  child: Image.asset(
                    'assets/branding/senior_shield_icon.png',
                    width: 136,
                    height: 136,
                    fit: BoxFit.contain,
                    excludeFromSemantics: true,
                  ),
                ),
                const SizedBox(height: 24),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF142D46),
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: const Color(0xFF3A657E)),
                  ),
                  child: const Text('YOUR DIGITAL SAFETY COMPANION',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 13, letterSpacing: 1.5,
                          color: Color(0xFFB3F7FF), fontWeight: FontWeight.bold)),
                ),
                const SizedBox(height: 20),
                const Text(
                  'Is This a Scam?',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Check a suspicious message or link before responding.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 20),
                ),
                VoiceControls(
                  showSettings: true,
                  text: () => 'Welcome to Senior Shield. '
                      'Check a suspicious message or link before responding. '
                      'Choose Check a Message to look for scam warning signs. '
                      'Choose Get Family Help to call someone you trust. '
                      'Never share passwords, security codes, or banking information.',
                ),
                const SizedBox(height: 35),
                SizedBox(
                  width: double.infinity,
                  height: 65,
                  child: ElevatedButton.icon(
                    onPressed: () async {
                      await stopVoice();
                      if (!context.mounted) return;
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const CheckMessagePage(),
                        ),
                      );
                    },
                    icon: const Icon(Icons.search, size: 30),
                    label: const Text(
                      'Check a Message',
                      style: TextStyle(fontSize: 22),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  height: 65,
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      await stopVoice();
                      if (!context.mounted) return;
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const FamilyHelpPage(),
                        ),
                      );
                    },
                    icon: const Icon(Icons.family_restroom, size: 30),
                    label: const Text(
                      'Get Family Help',
                      style: TextStyle(fontSize: 22),
                    ),
                  ),
                ),
                const SizedBox(height: 30),
                const Text(
                  'Never share passwords, security codes, or banking information.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 17),
                ),
                const SizedBox(height: 25),
                InkWell(onTap: () => launchUrl(Uri.parse('https://www.halemcyberdefense.com')), child: const Text(
                  'Powered by Halem Cyber Defense',
                  style: TextStyle(fontWeight: FontWeight.bold),
                )),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CheckMessagePage extends StatefulWidget {
  const CheckMessagePage({super.key});

  @override
  State<CheckMessagePage> createState() => _CheckMessagePageState();
}

class _CheckMessagePageState extends State<CheckMessagePage> {
  final TextEditingController _controller = TextEditingController();

  String? _result;
  String? _explanation;
  Color _resultColor = Colors.green;
  List<String> _warningSigns = [];

  void _analyzeMessage() {
    unawaited(stopVoice());
    final message = _controller.text.trim().toLowerCase();

    if (message.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please paste or type a message first.')),
      );
      return;
    }

    int score = 0;
    final warnings = <String>[];

    if (RegExp(r'https?://|www\.').hasMatch(message)) {
      score += 15;
      warnings.add('The message contains a website link.');
    }

    if (RegExp(r'urgent|immediately|act now|final warning').hasMatch(message)) {
      score += 20;
      warnings.add('It pressures you to act quickly.');
    }

    if (RegExp(
      r'password|pin|security code|verification code|social security|ssn',
    ).hasMatch(message)) {
      score += 35;
      warnings.add('It asks for sensitive personal information.');
    }

    if (RegExp(r'gift card|bitcoin|crypto|wire transfer|send money|payment')
        .hasMatch(message)) {
      score += 35;
      warnings.add('It mentions an unusual or risky payment method.');
    }

    if (RegExp(r'prize|winner|lottery|inheritance|free money')
        .hasMatch(message)) {
      score += 25;
      warnings.add('It promises money or a prize.');
    }

    if (RegExp(r'do not tell|keep this secret|confidential')
        .hasMatch(message)) {
      score += 25;
      warnings.add('It tells you to keep the message secret.');
    }

    if (RegExp(r'account.*closed|account.*suspended|account.*locked')
        .hasMatch(message)) {
      score += 25;
      warnings.add('It threatens a problem with your account.');
    }

    if (score > 100) {
      score = 100;
    }

    setState(() {
      _warningSigns = warnings;

      if (score >= 50) {
        _result = 'LIKELY SCAM';
        _resultColor = const Color(0xFFB3261E);
        _explanation =
            'Do not reply, click links, send money, or share information.';
      } else if (score >= 20) {
        _result = 'BE CAREFUL';
        _resultColor = const Color(0xFF9A6700);
        _explanation =
            'Verify the sender using a trusted phone number or website.';
      } else {
        _result = 'NO OBVIOUS SCAM SIGNS';
        _resultColor = const Color(0xFF18794E);
        _explanation = 'Stay cautious. This result cannot guarantee that the message is safe.';
      }
    });
  }

  void _clearMessage() {
    unawaited(stopVoice());
    _controller.clear();

    setState(() {
      _result = null;
      _explanation = null;
      _warningSigns = [];
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: const Text(
          'Check a Message',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 600),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'Paste the suspicious message below.',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                const Text(
                  'Your message is checked on this device.',
                  style: TextStyle(fontSize: 17),
                ),
                VoiceControls(
                  text: () => 'Paste or type the suspicious message in the text box. '
                      'Then press Check for Scam. '
                      'After checking, press Listen to Result to hear the advice. '
                      'This check cannot guarantee that a message is safe.',
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: _controller,
                  onChanged: (_) {
                    unawaited(stopVoice());
                    if (_result != null) {
                      setState(() {
                        _result = null;
                        _explanation = null;
                        _warningSigns = [];
                      });
                    }
                  },
                  minLines: 6,
                  maxLines: 10,
                  style: const TextStyle(fontSize: 19),
                  decoration: const InputDecoration(
                    hintText: 'Paste or type the message here...',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  height: 60,
                  child: ElevatedButton.icon(
                    onPressed: _analyzeMessage,
                    icon: const Icon(Icons.security, size: 28),
                    label: const Text(
                      'Check for Scam',
                      style: TextStyle(fontSize: 21),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                TextButton(
                  onPressed: _clearMessage,
                  child: const Text(
                    'Clear Message',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
                if (_result != null) ...[
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(22),
                    decoration: BoxDecoration(
                      color: _resultColor,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      children: [
                        Text(
                          _result!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 27,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          _explanation!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                          ),
                        ),
                      ],
                    ),
                  ),
                  VoiceControls(
                    label: 'Listen to Result',
                    text: () => [
                      _result ?? '',
                      _explanation ?? '',
                      if (_warningSigns.isNotEmpty) 'Warning signs found.',
                      ..._warningSigns,
                    ].join(' '),
                  ),
                  if (_warningSigns.isNotEmpty) ...[
                    const SizedBox(height: 20),
                    const Text(
                      'Warning signs found:',
                      style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 10),
                    ..._warningSigns.map(
                      (warning) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Icon(
                              Icons.warning_amber,
                              color: Color(0xFFB3261E),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                warning,
                                style: const TextStyle(fontSize: 18),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class FamilyHelpPage extends StatelessWidget {
  const FamilyHelpPage({super.key});

Future<void> _callFamily(BuildContext context) async {
  await stopVoice();
  if (!context.mounted) return;
  try {
    final contact =
        await FlutterNativeContactPicker().selectPhoneNumber();
    final number = contact?.selectedPhoneNumber?.trim();
    if (number == null || number.isEmpty || !context.mounted) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Call this family member?'),
        content: Text('${contact!.fullName ?? 'Selected contact'}\n$number'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Open phone'),
          ),
        ],
      ),
    );
    if (confirmed != true || !context.mounted) return;

    final opened = await launchUrl(Uri(scheme: 'tel', path: number));
    if (!opened && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('The phone app could not be opened.')),
      );
    }
  } catch (_) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open contacts. Try again.')),
      );
    }
  }
}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: const Text(
          'Get Family Help',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 550),
            child: Column(
              children: [
                const Icon(
                  Icons.family_restroom,
                  size: 90,
                  color: Color(0xFF70EAF5),
                ),
                const SizedBox(height: 20),
                const Text(
                  'Stop Before You Respond',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 25),
                VoiceControls(
                  text: () => 'Stop before you respond. '
                      'One. Do not click the link or answer the message. '
                      'Two. Do not send money or share personal information. '
                      'Three. Call a trusted family member using a number you already know. '
                      'Four. If banking information was shared, contact your bank immediately. '
                      'Press Call a Trusted Family Member to choose a contact. '
                      'When in doubt, stop and ask someone you trust.',
                ),
                _helpStep('1', 'Do not click the link or answer the message.'),
                _helpStep(
                  '2',
                  'Do not send money or share personal information.',
                ),
                _helpStep(
                  '3',
                  'Call a trusted family member using a number you already know.',
                ),
                _helpStep(
                  '4',
                  'If banking information was shared, contact your bank immediately.',
                ),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(

                   onPressed: () => _callFamily(context),
                    icon: const Icon(Icons.phone),
                    label: const Text('Call a Trusted Family Member'),
                  ),
                ),
                const SizedBox(height: 20),
                const SizedBox(height: 25),
                const Text(
                  'When in doubt, stop and ask someone you trust.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF70EAF5),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _helpStep(String number, String text) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: const Color(0xFF70EAF5),
              child: Text(number, style: const TextStyle(color: Color(0xFF061522))),
            ),
            const SizedBox(width: 15),
            Expanded(child: Text(text, style: const TextStyle(fontSize: 19))),
          ],
        ),
      ),
    );
  }
}
